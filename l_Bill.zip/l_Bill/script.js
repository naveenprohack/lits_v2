document.getElementById('receiptForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const no = document.getElementById('no').value;
    const name = document.getElementById('name').value;
    const dueDate = document.getElementById('dueDate').value;
    const course = document.getElementById('course').value;
    const registrationFee = document.getElementById('registrationFee').value;
    const tuitionFee = document.getElementById('tuitionFee').value;
    const examinationFee = document.getElementById('examinationFee').value || '-';
    const otherFee = document.getElementById('otherFee').value || '-';
    const total = parseFloat(registrationFee) + parseFloat(tuitionFee) + parseFloat(examinationFee) + parseFloat(otherFee);

    document.getElementById('receiptNo').textContent = no;
    document.getElementById('receiptName').textContent = name;
    document.getElementById('receiptDueDate').textContent = dueDate;
    document.getElementById('receiptCourse').textContent = course;
    document.getElementById('receiptRegistrationFee').textContent = registrationFee;
    document.getElementById('receiptTuitionFee').textContent = tuitionFee;
    document.getElementById('receiptExaminationFee').textContent = examinationFee === '0' ? '-' : examinationFee;
    document.getElementById('receiptOtherFee').textContent = otherFee === '0' ? '-' : otherFee;
    document.getElementById('receiptTotal').textContent = total;
});

function printReceipt() {
    window.print();
}

function downloadReceipt() {
    const element = document.getElementById('receipt-container');
    html2canvas(element).then((canvas) => {
        const imgData = canvas.toDataURL('');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 210;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
        pdf.save('receipt.pdf');
    });
}
